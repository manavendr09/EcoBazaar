package com.example.userlogin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserloginApplicationTests {

	@Test
	void contextLoads() {
	}

}
